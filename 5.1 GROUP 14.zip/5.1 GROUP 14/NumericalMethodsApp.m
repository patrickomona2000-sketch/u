function NumericalMethodsApp
    % NumericalMethodsApp - simple programmatic GUI for the numerical methods
    fig = uifigure('Name','Numerical Methods GUI','Position',[200 100 900 620]);
    fig.Color = [0.98 0.98 1];

    uilabel(fig, 'Text','Numerical Methods Application', ...
        'FontSize',18, 'FontWeight','bold', ...
        'Position',[260 560 400 30]);

    % Problem type dropdown
    uilabel(fig,'Text','Select Problem Type:','Position',[30 510 150 22]);
    probType = uidropdown(fig, ...
        'Items',{'Root Finding','Differential Equation','Integration'}, ...
        'Position',[180 510 200 22], ...
        'Value','Root Finding', ...
        'ValueChangedFcn',@updateMethodList);

    % Method dropdown
    uilabel(fig,'Text','Select Method:','Position',[30 470 150 22]);
    methodList = uidropdown(fig, ...
        'Items',{'Newton-Raphson','Secant','Bisection'}, ...
        'Position',[180 470 200 22]);

    % Parameter area (basic inputs)
    uilabel(fig,'Text','Parameters (example):','Position',[420 510 200 22]);
    paramsArea = uitextarea(fig,'Position',[420 430 450 70], 'Value', {'Uses default examples. To customize edit code.'});

    % Buttons
    runBtn = uibutton(fig,'push','Text','Run','FontSize',14, ...
        'Position',[420 370 100 40],'ButtonPushedFcn',@runMethod);
    uibutton(fig,'push','Text','Clear Plot','FontSize',12, ...
        'Position',[530 370 100 40],'ButtonPushedFcn',@(s,e)cla(ax));
    uibutton(fig,'push','Text','Exit','FontSize',12, ...
        'Position',[640 370 100 40],'ButtonPushedFcn',@(s,e)close(fig));

    % Axes
    ax = uiaxes(fig,'Position',[30 40 580 410]);
    title(ax,'Computation Results'); grid(ax,'on');

    % Results area
    resultBox = uitextarea(fig,'Position',[630 40 240 300], 'Editable','off', 'FontSize',11);
    resultBox.Value = {'Results will appear here...'};

    % Update method list callback
    function updateMethodList(~,~)
        switch probType.Value
            case 'Root Finding'
                methodList.Items = {'Newton-Raphson','Secant','Bisection'};
            case 'Differential Equation'
                methodList.Items = {'Euler','RK2','RK4'};
            case 'Integration'
                methodList.Items = {'Trapezoid','Simpson'};
        end
    end

    % Run method callback
    function runMethod(~,~)
        cla(ax); drawnow;
        switch probType.Value
            case 'Root Finding'
                f = @(x) x.^3 - x - 2;
                df = @(x) 3*x.^2 - 1;
                try
                    switch methodList.Value
                        case 'Newton-Raphson'
                            tic; [r,iter] = NumericalMethod.newtonRaphson(f,df,1.5,1e-8,100); t = toc;
                        case 'Secant'
                            tic; [r,iter] = NumericalMethod.secantMethod(f,1,2,1e-8,100); t = toc;
                        case 'Bisection'
                            tic; [r,iter] = NumericalMethod.bisectionMethod(f,1,2,1e-8,100); t = toc;
                    end
                catch ME
                    resultBox.Value = {['Error: ' ME.message]}; return;
                end
                x = linspace(0,3,500);
                plot(ax,x,f(x), 'LineWidth',1.4); hold(ax,'on');
                plot(ax,r,0,'ro','MarkerFaceColor','r','MarkerSize',8);
                title(ax,sprintf('%s Method — Root ≈ %.8f', methodList.Value, r));
                resultBox.Value = {sprintf('Root: %.10f', r); sprintf('Iterations: %d', iter); sprintf('Time: %.6f s', t)};

            case 'Differential Equation'
                odefun = @(t,y) -2*y + exp(-t);
                y_true = @(t) (1/3)*exp(-2*t) + (2/3)*exp(-t);
                odeObj = DiffProblem(odefun, y_true, 0, 5, 1, 0.1);
                try
                    res = odeObj.solve(lower(methodList.Value));
                catch ME
                    resultBox.Value = {['Error: ' ME.message]}; return;
                end
                plot(ax,res.t,res.y,'LineWidth',1.6); hold(ax,'on');
                if ~isempty(res.y_true)
                    plot(ax,res.t,res.y_true,'k--','LineWidth',1.4);
                    legend(ax,methodList.Value,'Analytical','Location','best');
                else
                    legend(ax,methodList.Value,'Location','best');
                end
                title(ax,sprintf('ODE Solution — %s', methodList.Value));
                resultBox.Value = {sprintf('Method: %s', res.method); sprintf('Time: %.6f s', res.time); sprintf('Max Error: %.6e', res.maxError)};

            case 'Integration'
                f = @(x) sin(x).^2; a = 0; b = pi; n = 200;
                intObj = IntegralProblem(f,a,b,n);
                try
                    res = intObj.solve(lower(methodList.Value));
                catch ME
                    resultBox.Value = {['Error: ' ME.message]}; return;
                end
                xx = linspace(a,b,400);
                plot(ax,xx,f(xx),'LineWidth',1.4); hold(ax,'on');
                area(ax,xx,f(xx));
                title(ax,sprintf('Integration — %s (I ≈ %.8f)', methodList.Value, res.I));
                resultBox.Value = {sprintf('Method: %s', res.method); sprintf('I ≈ %.10f', res.I); sprintf('Time: %.6f s', res.time)};
        end
    end
end
